#!/usr/bin/env node
// GARP 2.5.1 GHRAB - check-sw-security-freeze (KS 5.10.25 hardened copy)
// Static guard against precaching or cache-first serving of security-critical assets.
// Important: precache discovery must not depend on variable names. It resolves array
// literals used by cache.add/cache.addAll via direct calls, map/forEach and for..of.
import { readFile, readdir, lstat } from 'node:fs/promises';
import path from 'node:path';

const [swPath, deployDirArg, listArg] = process.argv.slice(2);
if (!swPath || !deployDirArg) {
  console.error('Usage: node check-sw-security-freeze.mjs <sw.js> <deployment-dir> [security-critical-list.json]');
  process.exit(2);
}
const DEFAULT_CRITICAL = [
  'app-guard', 'access-control', 'platform-runtime', 'revoked-access.json',
  'release-integrity.json', 'release-integrity.sig', 'integrity-status', 'runtime-config'
];
const critical = listArg ? JSON.parse(await readFile(listArg, 'utf8')) : DEFAULT_CRITICAL;
const sw = await readFile(swPath, 'utf8');
const deployRoot = path.resolve(deployDirArg);
const findings = [];

const norm = value => String(value || '').replace(/^\.\//, '').replace(/^\//, '');
const matchesCritical = value => critical.some(c => norm(value).includes(norm(c)));

async function walk(dir, base = '') {
  const out = [];
  for (const name of (await readdir(dir)).sort()) {
    const abs = path.join(dir, name), rel = path.posix.join(base, name);
    const st = await lstat(abs);
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) out.push(...await walk(abs, rel));
    else if (st.isFile()) out.push(rel);
  }
  return out;
}
let files;
try { files = await walk(deployRoot); }
catch (e) { console.error(JSON.stringify({ status: 'ERROR', error: String(e) })); process.exit(2); }

const criticalFiles = files.filter(f => matchesCritical(f));
if (!criticalFiles.length) {
  findings.push({ severity: 'INFO', issue: 'zadny security-critical asset nenalezen - overit seznam rucne', detail: critical.join(',') });
}

function stringsFrom(text) {
  const out = [];
  const re = /(['"`])((?:\\.|(?!\1)[\s\S])*)\1/g;
  for (const m of text.matchAll(re)) {
    // Static paths in SW are plain literals; skip template expressions to avoid pretending to resolve them.
    if (m[1] === '`' && m[2].includes('${')) continue;
    out.push(m[2].replace(/\\(['"`\\])/g, '$1'));
  }
  return out;
}

// Discover every simple array literal assigned to any identifier. No allowlist of names.
const arrays = new Map();
for (const m of sw.matchAll(/\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*\[([\s\S]*?)\]\s*;?/g)) {
  arrays.set(m[1], stringsFrom(m[2]));
}

const precached = new Set();
const precacheSources = [];
const add = (items, source) => {
  const values = [...new Set(items.filter(Boolean))];
  for (const item of values) precached.add(item);
  if (values.length) precacheSources.push({ source, entries: values });
};

// cache.addAll(ARRAY_IDENTIFIER)
for (const m of sw.matchAll(/\.\s*addAll\s*\(\s*([A-Za-z_$][\w$]*)\s*\)/g)) {
  add(arrays.get(m[1]) || [], `addAll:${m[1]}`);
}
// cache.addAll(["literal", ...])
for (const m of sw.matchAll(/\.\s*addAll\s*\(\s*\[([\s\S]*?)\]\s*\)/g)) {
  add(stringsFrom(m[1]), 'addAll:literal-array');
}
// cache.add("literal")
for (const m of sw.matchAll(/\.\s*add\s*\(\s*(['"`])((?:\\.|(?!\1)[\s\S])*)\1\s*\)/g)) {
  if (!(m[1] === '`' && m[2].includes('${'))) add([m[2]], 'add:literal');
}
// ARRAY.map(... cache.add(...)) / ARRAY.forEach(... cache.add(...))
for (const m of sw.matchAll(/\b([A-Za-z_$][\w$]*)\s*\.(?:map|forEach)\s*\([\s\S]{0,500}?\.\s*add\s*\(/g)) {
  add(arrays.get(m[1]) || [], `iterated-add:${m[1]}`);
}
// for (... of ARRAY) { ... cache.add(...) }
for (const m of sw.matchAll(/\bfor\s*\([^)]*\bof\s+([A-Za-z_$][\w$]*)\s*\)[\s\S]{0,500}?\.\s*add\s*\(/g)) {
  add(arrays.get(m[1]) || [], `for-of-add:${m[1]}`);
}

for (const p of precached) {
  for (const c of critical) {
    if (norm(p).includes(norm(c))) {
      findings.push({ severity: 'CRITICAL', issue: 'security-critical asset je v precache SW', detail: `${p} (vzor: ${c})` });
    }
  }
}

const hasCacheFirst = /caches\.match\s*\([^)]*\)\s*\.then\s*\(\s*(?:\w+)\s*=>\s*\1?\s*\|\|/.test(sw)
  || /cacheFirst|CacheFirst|StaleWhileRevalidate|staleWhileRevalidate/.test(sw)
  || /const\s+cached\s*=\s*await\s+cache(?:s)?\.match[\s\S]{0,200}if\s*\(\s*cached\s*\)\s*return\s+cached/.test(sw);
const securityCriticalFn = sw.match(/function\s+isSecurityCriticalRequest\s*\([^)]*\)\s*\{([\s\S]*?)\n\}/)?.[1] || '';
const securityCriticalHandlerIsNetworkOnly = /if\s*\(\s*isSecurityCriticalRequest\s*\([^)]*\)\s*\)\s*\{[\s\S]{0,300}?respondWith\s*\(\s*(?:networkOnlyNoStore|networkFirst|fetch)\s*\(/.test(sw);
const bypassed = critical.filter(c => {
  const esc = c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  if (securityCriticalHandlerIsNetworkOnly && securityCriticalFn.includes(c)) return true;
  const re = new RegExp(`${esc}[\\s\\S]{0,800}?(network|fetch\\(|no-store|bypass|skipCache|reload)`, 'i');
  const re2 = new RegExp(`(network|no-store|bypass|skipCache|reload)[\\s\\S]{0,800}?${esc}`, 'i');
  return re.test(sw) || re2.test(sw);
});
if (hasCacheFirst) {
  for (const c of critical) {
    const mentioned = sw.includes(c);
    if (mentioned && !bypassed.includes(c))
      findings.push({ severity: 'HIGH', issue: 'SW zna asset, ma cache-first strategii a nema pro nej network-first/no-store vetev', detail: c });
    if (!mentioned && criticalFiles.some(f => norm(f).includes(norm(c))))
      findings.push({ severity: 'HIGH', issue: 'security-critical asset existuje v deploymentu, ale SW jej nijak nevyjima z cache-first', detail: c });
  }
}

const runtimeFilter = sw.match(/function\s+isRuntimeRequest[\s\S]{0,600}?\n\}/);
if (runtimeFilter) {
  for (const c of critical) {
    if (runtimeFilter[0].includes(c))
      findings.push({ severity: 'MEDIUM', issue: 'security-critical asset je zminen ve filtru runtime requestu - overit, ze jej nevyrazuje z obsluhy', detail: c });
  }
}

for (const p of precached) if (/release-integrity\.(json|sig)$/.test(p))
  findings.push({ severity: 'CRITICAL', issue: 'integritni artefakt je precachovan - integrity check by overoval zmrazenou verzi', detail: p });

const blocking = findings.filter(f => f.severity === 'CRITICAL' || f.severity === 'HIGH');
const out = {
  status: blocking.length ? 'FAIL' : (findings.some(f => f.severity === 'MEDIUM') ? 'AMBER' : 'PASS'),
  serviceWorker: swPath,
  precachedEntries: precached.size,
  precacheSources,
  cacheFirstDetected: hasCacheFirst,
  criticalAssetsInDeployment: criticalFiles,
  findings,
  checkerRevision: 'ks-5.10.25-variable-name-independent-precache-discovery',
  note: 'Staticka kontrola. Nenahrazuje SIM-07 (update/recovery) ani behavioralni test revokace v prohlizeci.'
};
console[blocking.length ? 'error' : 'log'](JSON.stringify(out, null, 2));
process.exit(blocking.length ? 1 : 0);
