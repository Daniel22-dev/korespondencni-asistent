#!/usr/bin/env node
// Verify cryptographic linkage from signed release-integrity.json to assurance artifacts.
// The manifest signature protects the expected hashes; this verifier rejects substitution.
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const argv = process.argv.slice(2);
const opt = k => { const i = argv.indexOf(`--${k}`); return i >= 0 ? argv[i + 1] : null; };
const manifestPath = opt('manifest');
if (!manifestPath) {
  console.error('Usage: node verify-assurance-links.mjs --manifest release-integrity.json [--provenance file] [--evidence-manifest file] [--sbom file] [--deployment-package file]');
  process.exit(2);
}

const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
const links = [
  ['buildProvenanceSha256', 'provenance'],
  ['evidenceManifestSha256', 'evidence-manifest'],
  ['sbomSha256', 'sbom'],
  ['deploymentPackageSha256', 'deployment-package'],
];
const errors = [];
const observed = [];
const sha = async p => createHash('sha256').update(await readFile(p)).digest('hex');

for (const [field, arg] of links) {
  const expected = manifest[field] ?? null;
  const file = opt(arg);
  if (expected === null) {
    observed.push({ field, status: 'N/A', expected: null, file: file || null });
    continue;
  }
  if (!/^[0-9a-f]{64}$/.test(expected)) {
    errors.push(`${field}:invalid-manifest-hash`);
    continue;
  }
  if (!file) {
    errors.push(`${field}:required-linked-artifact-missing`);
    continue;
  }
  try {
    const actual = await sha(file);
    observed.push({ field, status: actual === expected ? 'PASS' : 'FAIL', expected, actual, file });
    if (actual !== expected) errors.push(`${field}:hash-mismatch`);
  } catch {
    errors.push(`${field}:unreadable:${file}`);
  }
}

const out = {
  schema: 'ghrab-assurance-links-verification-v1',
  status: errors.length ? 'FAIL' : 'PASS',
  manifest: manifestPath,
  observed,
  errors,
  note: 'deploymentPackageSha256 may refer to the pre-sign deployment payload package. The final signed bundle is externally hashed because embedding its own final hash would be self-referential.'
};
console[errors.length ? 'error' : 'log'](JSON.stringify(out, null, 2));
process.exit(errors.length ? 1 : 0);
