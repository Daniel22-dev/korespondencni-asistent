#!/usr/bin/env node
// GARP 2.5.1 GHRAB - release-gate
// SH-SC-11 (bypass resistance) mel v GARP 2.5 jen textovy pozadavek. Jednotlive
// verifiery slo spustit v libovolnem poradi nebo nespustit vubec a nic to nezachytilo.
// Tento gate je jediny vstupni bod: chybejici vstup = FAIL, nikoli preskoceni.
//
// Usage:
//   node release-gate.mjs --deploy dist --manifest dist/release-integrity.json \
//     --signature dist/release-integrity.sig --trust-root trust-root.json \
//     --registry release-registry.json --artifact build.zip --provenance prov.json \
//     --evidence-dir audit-evidence --evidence-manifest evidence.json \
//     --profile school|prep
import { spawnSync } from 'node:child_process';
import { access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const opt = k => { const i = argv.indexOf(`--${k}`); return i >= 0 ? argv[i + 1] : null; };
const profile = opt('profile') || 'school';

const REQUIRED = {
  school: ['deploy', 'manifest', 'signature', 'trust-root', 'registry', 'artifact', 'provenance', 'evidence-dir', 'evidence-manifest'],
  prep: ['deploy', 'manifest', 'signature', 'trust-root']
};
if (!REQUIRED[profile]) { console.error(JSON.stringify({ status: 'FAIL', errors: [`unknown-profile:${profile}`] })); process.exit(2); }

const steps = [];
const missing = [];
for (const k of REQUIRED[profile]) {
  const v = opt(k);
  if (!v) { missing.push(k); continue; }
  try { await access(v); } catch { missing.push(`${k}:${v}:unreadable`); }
}
if (missing.length) {
  console.error(JSON.stringify({ status: 'FAIL', profile, errors: ['required-input-missing'], missing }, null, 2));
  process.exit(1);
}

run('deployment-leaks', 'scan-deployment-leaks.mjs', [opt('deploy')]);
run('release-integrity', 'verify-release-integrity.mjs', [opt('deploy'), opt('manifest')]);
run('release-signature', 'verify-release-signature.mjs', [opt('manifest'), opt('signature'), opt('trust-root')]);
if (opt('registry')) run('release-registry', 'verify-release-registry.mjs', [opt('manifest'), opt('registry')]);
if (opt('artifact') && opt('provenance'))
  run('build-provenance', 'verify-build-provenance.mjs',
    [opt('artifact'), opt('provenance'), ...(profile === 'prep' ? ['--allow-local-builder'] : [])]);
if (opt('evidence-dir') && opt('evidence-manifest'))
  run('evidence-manifest', 'verify-evidence-manifest.mjs', [opt('evidence-dir'), opt('evidence-manifest')]);
run('assurance-links', 'verify-assurance-links.mjs', [
  '--manifest', opt('manifest'),
  ...(opt('provenance') ? ['--provenance', opt('provenance')] : []),
  ...(opt('evidence-manifest') ? ['--evidence-manifest', opt('evidence-manifest')] : []),
  ...(opt('sbom') ? ['--sbom', opt('sbom')] : []),
  ...(opt('deployment-package') ? ['--deployment-package', opt('deployment-package')] : []),
]);
if (opt('sw') && opt('deploy')) run('sw-security-freeze', 'check-sw-security-freeze.mjs', [opt('sw'), opt('deploy')]);
if (opt('vendored-config')) run('vendored-consistency', 'check-vendored-consistency.mjs', [opt('vendored-config')]);

const failed = steps.filter(s => s.status !== 'PASS');
const verdict = {
  gate: 'GARP-2.5.1-RELEASE-GATE',
  profile,
  status: failed.length ? 'RED' : 'GREEN',
  steps,
  note: profile === 'prep'
    ? 'PREP profil nevynucuje registry, provenance ani evidence. Neni to skolni release GREEN.'
    : 'Skolni profil: vsechny povinne vstupy byly pritomne a overene.'
};
console[failed.length ? 'error' : 'log'](JSON.stringify(verdict, null, 2));
process.exit(failed.length ? 1 : 0);

function run(name, script, args) {
  const r = spawnSync(process.execPath, [path.join(here, script), ...args], { encoding: 'utf8' });
  steps.push({
    step: name, script, status: r.status === 0 ? 'PASS' : 'FAIL', exitCode: r.status,
    detail: (r.status === 0 ? r.stdout : (r.stderr || r.stdout)).trim().slice(0, 800)
  });
}
