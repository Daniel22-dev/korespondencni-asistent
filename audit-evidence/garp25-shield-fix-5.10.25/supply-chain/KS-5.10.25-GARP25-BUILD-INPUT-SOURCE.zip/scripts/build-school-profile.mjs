import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const root = process.cwd();
const BUILD_TIME = process.env.GHRAB_BUILD_TIME || new Date().toISOString();
const sourceDist = path.join(root, "dist");
const targetDist = path.join(root, "dist-school-server");
if (!fs.existsSync(sourceDist)) throw new Error("Chybí dist/. Nejprve spusťte standardní build.");
fs.rmSync(targetDist, { recursive: true, force: true });
fs.cpSync(sourceDist, targetDist, { recursive: true });

function walk(dir) {
  const files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else files.push(full);
  }
  return files;
}
function readJson(file) { return JSON.parse(fs.readFileSync(file, "utf8")); }
function writeJson(file, value) { fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`); }
function trailingSlash(value) { return String(value || "/").replace(/\/+$/, "") + "/"; }

let files = walk(targetDist);
const schoolProfiles = files.filter((file) => file.endsWith(`${path.sep}config${path.sep}deployment.school-server.json`));
if (!schoolProfiles.length) throw new Error("Build neobsahuje config/deployment.school-server.json.");
for (const profile of schoolProfiles) fs.copyFileSync(profile, path.join(path.dirname(profile), "deployment.json"));

files = walk(targetDist);
for (const runtimeProfile of files.filter((file) => file.endsWith(`${path.sep}runtime-config.school-server.js`))) {
  fs.copyFileSync(runtimeProfile, path.join(path.dirname(runtimeProfile), "runtime-config.js"));
}
for (const manifestPath of files.filter((file) => file.endsWith(`${path.sep}manifest.webmanifest`))) {
  const manifest = readJson(manifestPath);
  manifest.id = "./";
  manifest.start_url = "./";
  manifest.scope = "./";
  writeJson(manifestPath, manifest);
}

// School-server build must not retain a direct-provider network allowance. The
// shared Core still contains both adapters, but runtime permits only school-gateway.
for (const htmlPath of files.filter((file) => file.endsWith('.html'))) {
  const raw = fs.readFileSync(htmlPath, 'utf8');
  const hardened = raw.replace(/connect-src 'self' https:\/\/generativelanguage\.googleapis\.com;/g, "connect-src 'self';");
  fs.writeFileSync(htmlPath, hardened);
}

const deployment = readJson(path.join(path.dirname(schoolProfiles[0]), "deployment.json"));
if (!deployment.appId || deployment.profile !== "school-server" || deployment.authMode !== "server-session") {
  throw new Error("Aktivní school-server deployment kontrakt není úplný.");
}
const appBaseUrl = trailingSlash(deployment.appBaseUrl || deployment.appBaseUrls?.[deployment.appId]);
if (!appBaseUrl.startsWith("/")) throw new Error("School-server appBaseUrl musí být same-origin absolutní cesta.");
const studioBaseUrl = trailingSlash(deployment.studioBaseUrl || deployment.appBaseUrls?.["ai-studio"]);
if (!studioBaseUrl.startsWith("/")) throw new Error("School-server studioBaseUrl musí být same-origin absolutní cesta.");

// The standalone source intentionally points to the GitHub Pages Studio path.
// In the school-server artifact every runtime reference must follow the active
// deployment contract instead of retaining that standalone path.
const standaloneStudioBaseUrl = "/AI-Studio-GHRAB/";
const schoolTextExtensions = new Set([".html", ".js", ".json", ".css", ".webmanifest"]);
for (const runtimeFile of walk(targetDist).filter((file) => schoolTextExtensions.has(path.extname(file)))) {
  const relativeRuntimeFile = path.relative(targetDist, runtimeFile).split(path.sep).join('/');
  // Shared error-reporter implementation stays byte-identical to the canonical source.
  // Deployment-specific Studio/guide URLs are supplied by the local adapter, which may be rewritten.
  if (relativeRuntimeFile === 'access/error-reporter.js') continue;
  const raw = fs.readFileSync(runtimeFile, "utf8");
  if (!raw.includes(standaloneStudioBaseUrl)) continue;
  fs.writeFileSync(runtimeFile, raw.split(standaloneStudioBaseUrl).join(studioBaseUrl));
}

for (const manifestPath of files.filter((file) => file.endsWith(`${path.sep}studio-manifest.json`))) {
  const manifest = readJson(manifestPath);
  manifest.deploymentProfile = "school-server";
  manifest.serverReadyPhase = "P3";
  manifest.launchUrl = appBaseUrl;
  manifest.manualUrl = `${appBaseUrl}manual/`;
  if (manifest.aiCore?.status === "integrated-p1" || manifest.aiCore?.coreVersion) {
    manifest.aiCore.operationsManifestUrl = `${appBaseUrl}ai-operations.json`;
  } else if (manifest.aiCore && typeof manifest.aiCore === "object") {
    delete manifest.aiCore.operationsManifestUrl;
  }
  writeJson(manifestPath, manifest);
}

for (const stale of files.filter((file) => file.endsWith(`${path.sep}deployment.school-server-p0.json`))) {
  fs.rmSync(stale, { force: true });
}

for (const htmlPath of walk(targetDist).filter((file) => file.endsWith('.html'))) {
  const raw = fs.readFileSync(htmlPath, 'utf8');
  const csp = raw.match(/<meta\s+[^>]*http-equiv=["']Content-Security-Policy["'][^>]*content=["']([^"']*)["']/i)?.[1] || '';
  if (/generativelanguage\.googleapis\.com/i.test(csp)) throw new Error(`School-server CSP stále povoluje přímý Gemini endpoint: ${path.relative(targetDist, htmlPath)}`);
}
const schoolRuntimeText = fs.readFileSync(path.join(targetDist, 'runtime-config.js'), 'utf8');
if (!schoolRuntimeText.includes('defaultMode: "school-gateway"') || /gemini-|openai|anthropic/i.test(schoolRuntimeText)) {
  throw new Error('School-server runtime není provider-neutrální school-gateway konfigurace.');
}

const staleStandaloneRefs = [];
for (const runtimeFile of walk(targetDist).filter((file) => schoolTextExtensions.has(path.extname(file)))) {
  const relativeRuntimeFile = path.relative(targetDist, runtimeFile).split(path.sep).join('/');
  if (relativeRuntimeFile === 'access/error-reporter.js') continue;
  const raw = fs.readFileSync(runtimeFile, "utf8");
  if (raw.includes(standaloneStudioBaseUrl)) staleStandaloneRefs.push(path.relative(targetDist, runtimeFile));
}
if (staleStandaloneRefs.length) {
  throw new Error(`School-server build obsahuje standalone Studio cestu: ${staleStandaloneRefs.join(", ")}`);
}
const expectedGuardUrl = `${studioBaseUrl}access/app-guard.js`;
for (const entry of [path.join(targetDist, "index.html"), path.join(targetDist, "manual", "index.html")]) {
  const raw = fs.readFileSync(entry, "utf8");
  if (!raw.includes(expectedGuardUrl)) throw new Error(`School-server bootstrap nepoužívá ${expectedGuardUrl}: ${path.relative(targetDist, entry)}`);
}

const pkg = readJson(path.join(root, "package.json"));
writeJson(path.join(targetDist, "server-ready-build-info.json"), {
  schema: "ghrab-server-ready-build-v1",
  app: pkg.name,
  appId: deployment.appId,
  version: pkg.version,
  phase: "P3",
  profile: "school-server",
  builtAt: BUILD_TIME,
  activeAuthMode: deployment.authMode,
  activeAiTransport: deployment.aiTransport,
  telemetryMode: deployment.telemetryMode,
  appBaseUrl,
  studioBaseUrl,
  apiBaseUrl: deployment.apiBaseUrl,
  containsSecrets: false,
  localProviderKeysAllowed: false,
  serverSessionReady: deployment.features?.serverSessionReady === true,
  schoolGatewayReady: deployment.aiTransport === "school-gateway" ? deployment.features?.schoolGatewayReady === true : null,
  aiCoreVersion: deployment.aiTransport === "school-gateway" ? "1.0.0" : null,
  contractVersion: deployment.aiTransport === "school-gateway" ? "1" : null,
});
console.log(`${pkg.name} ${pkg.version}: dist-school-server/ sestaven jako same-origin P3 school-server profil.`);
