# KS 5.10.25 – požadavky na school-server deployment

Tento dokument je **PREP design**, nikoli důkaz živého serveru.

## Proces a soubory
- aplikaci servírovat z dedikovaného read-only deployment adresáře;
- proces/gateway provozovat pod neprivilegovanou service identity, bez shellu a bez write oprávnění do web rootu;
- private signing key nesmí být na web serveru ani v aplikačním ZIPu;
- trust root a Release Registry spravovat odděleně od běžného buildu;
- deploy přijmout jen po `release-gate.mjs`, RI verifikaci, anti-rollback a mixed-version kontrole.

## Síť a TLS
- pouze HTTPS; HSTS ověřit na served response;
- aplikace smí volat same-origin school gateway; provider egress povolit jen gateway službě;
- gateway provider/model allowlist je serverová politika, ne klientský parametr;
- CORS/default-deny pro cizí originy.

## Auth / session
- school profil: `server-session`;
- server musí vynutit revokaci/expiry nezávisle na klientovi;
- odebrání přístupu musí být behaviorálně ověřeno na již otevřené kartě;
- appId/audience se nesmí zaměnit mezi child aplikacemi.

## Secrets
- OpenAI/provider credentials pouze v serverovém secret store / environmentu s minimálním scope;
- nikdy do HTML, runtime configu, localStorage, logů, evidence ani error reporteru;
- rotace a incidentní revokace musí být popsány v provozním runbooku.

## Server hardening
- read-only filesystem pro aplikaci, dočasný zápis jen do explicitního temp prostoru;
- non-root, minimální OS capabilities;
- rozumné memory/CPU/request limity;
- rate-limit per user/session + globální circuit breaker;
- request-size a output/token stropy z AI resource budgetu;
- timeout/cancel; retry pouze omezeně a idempotentně;
- structured logging bez promptu/odpovědi/student PII;
- záloha Release Registry/trust root a kontrolovaný recovery postup.

## HTTP security headers
Před LIVE ověřit skutečnou odpověď: CSP bez `unsafe-inline` nebo schválená nonce/hash migrace, HSTS, `X-Content-Type-Options: nosniff`, frame policy odpovídající řízenému Studio embeddingu, Referrer-Policy a vhodné Cache-Control pro security-critical soubory.

## Fail-closed
Nedostupný trust root, neplatný podpis, rollback, mixed release, neznámý keyId, revoked key, neplatná session nebo nesoulad appId => aplikace nesmí pokračovat v privilegovaném school režimu.

## LIVE status
Server enforcement: **NOT TESTED**.  
SHIELD-LIVE: **DEFERRED** do skutečného školního serveru.
